# recaptcha-for-salon-booking-system
	reCAPTCHA for Salon Booking System

## Prerequisite
	1 Install Wordpress plugin Salon Booking System first. Download https://wordpress.org/plugins/salon-booking-system/ 
	2 Make sure you have a Google Account

## After the installation of this plugin
	Go to Admin menu -> Salon -> reCAPTCHA
	Step 1 : Register a new site on https://www.google.com/recaptcha/admin/create (reCAPTCHA Google Admin Console)
	Step 2 : Enter a label for your reCAPTCHA site.
	Step 3 : Select reCAPTCHA version 2 and select Invisible reCAPTCHA-badge
	Step 4 : Enter the domainname of the site you working on.
	Step 5 : Agree with the terms and submit the form.
	Step 6 : Copy and Paste the private/site key in this form below.
	Step 7 : Thats it.